<?php
define('TEMPLATE_URL', get_template_directory_uri());

require get_template_directory() . '/inc/helper.php';
